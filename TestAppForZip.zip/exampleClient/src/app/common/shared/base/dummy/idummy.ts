export class IDummy {
  id: number;
  name?: string;
  parentId: number;
  parentDescriptiveField: string;
}
