export interface AssociationColumn {
  key: string;
  value: any;
  referencedkey: string;
}
